# AR EDUPOINT WebView APK

This Android project wraps the live AR EDUPOINT GitHub Pages website:

https://aredupoint.github.io/AR-EDUPOINT/

## Important behavior

- The APK loads the live website, not a copied HTML file.
- JavaScript and DOM storage are enabled.
- Android WebView pinch zoom is enabled.
- Built-in zoom buttons are hidden; pinch in/out is used.
- Back button navigates WebView history before closing the app.
- Changes deployed to GitHub Pages can appear in the installed APK without reinstalling the APK.

## Build

The included GitHub Actions workflow builds a debug APK automatically.

Open the repository's **Actions** tab and run **Build AR EDUPOINT APK**.
